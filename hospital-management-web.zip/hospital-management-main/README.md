# Hospital-management

#Login
    There are separate logins for doctors and the patients, and the patients can view their appointment by entering their details

The doctors can approve or cancel an appointment based on their availability
They can also book a appointment and review them 
